"""
file name: fig_stack_dispatch_mix_storage_no_ng.py
    plot dispatch mix for selected costs of renewables (wind and solar) 
    and varying costs of nuclear for cases having energy storage but no natural gas
    (supplementary figures)
"""

#%% import modules

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.ticker import FormatStrFormatter

#%% global plot settings

# set rcParams back to default values
    # reference: https://stackoverflow.com/questions/26413185/how-to-recover-matplotlib-defaults-after-setting-stylesheet
mpl.rcParams.update(mpl.rcParamsDefault)

# ticks
mpl.rcParams['xtick.direction'] = 'in'
mpl.rcParams['ytick.direction'] = 'in'

# font and fontsize
    # reference: https://ask.sagemath.org/question/8882/change-legend-font-when-plotting/
    # reference on font family: https://matplotlib.org/examples/api/font_family_rc.html
plt.rc('font',**{'family':'sans-serif','sans-serif':['Arial'],'size':8})

#%% color palette
# colors from: http://colorbrewer2.org/#type=diverging&scheme=BrBG&n=4

# colorblind-friendly
color_wind    = '#006d2c'   # green, dark
color_solar   = '#c7e9c0'   # green, light
color_nuclear = '#de2d26'   # red, dark
color_natgas  = '#6baed6'   # blue, medium
color_storage = '#762a83'   # purple, dark

# dispatch shares
colors = [color_wind, color_solar, color_storage, color_nuclear]    

#%% specify file path and file name

#file_path = '../no_ng_const_nuc_storage_500_4by21/'
#file_name = 'no_ng_const_nuc_storage_500_4by21_20181113_175109'

#file_path = '../no_ng_const_nuc_storage_100_4by21/'
#file_name = 'no_ng_const_nuc_storage_100_4by21_20181114_000124'

#file_path = '../no_ng_flex_nuc_storage_500_4by21/'
#file_name = 'no_ng_flex_nuc_storage_500_4by21_20181115_123249'

file_path = '../no_ng_flex_nuc_storage_100_4by21/'
file_name = 'no_ng_flex_nuc_storage_100_4by21_20181115_145117'


directory = file_path + 'figures'
if not os.path.exists(directory):
    os.mkdir(directory)

#%% read results from summary .csv files

# read data from .csv files as dataframes
    # reference: https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.html
df = pd.read_csv(file_path + file_name + '.csv')

# assign data to variable names
fixed_cost_solar = df['fixed cost solar ($/kW/h)'].values
fixed_cost_wind = df['fixed cost wind ($/kW/h)'].values
fixed_cost_nuclear = df['fixed cost nuclear ($/kW/h)'].values
dispatch_natgas = df['dispatch natgas (kW)'].values
dispatch_solar = df['dispatch solar (kW)'].values
dispatch_wind = df['dispatch wind (kW)'].values
dispatch_nuclear = df['dispatch nuclear (kW)'].values
dispatch_storage = df['dispatch from storage (kW)'].values
dispatch_to_storage = df['dispatch to storage (kW)'].values

#%% calculations

# number of columns and rows for re-arranged arrays
cols = np.unique(fixed_cost_nuclear).shape[0]
rows = np.unique(fixed_cost_solar).shape[0]

# calculate dispatch shares
# assume: dispatch to storage from each generation technology is proportional to dispatch from that technology
tot_gen = dispatch_natgas + dispatch_solar + dispatch_wind + dispatch_nuclear   # total generation
tot_dispatch = dispatch_natgas + dispatch_solar + dispatch_wind + dispatch_nuclear + \
    dispatch_storage - dispatch_to_storage   # = demand (= 1)
dispatch_share_natgas = dispatch_natgas * (1 - dispatch_to_storage/tot_gen) / tot_dispatch 
dispatch_share_solar = dispatch_solar * (1 - dispatch_to_storage/tot_gen) / tot_dispatch 
dispatch_share_wind = dispatch_wind * (1 - dispatch_to_storage/tot_gen) / tot_dispatch 
dispatch_share_renewables = dispatch_share_solar + dispatch_share_wind
dispatch_share_nuclear = dispatch_nuclear * (1 - dispatch_to_storage/tot_gen) / tot_dispatch 
dispatch_share_storage = dispatch_storage / tot_dispatch

#%% stack plot: dispatch mix (not including curtailment)

# stack up dispatch
dispatch_shares = np.vstack([dispatch_share_wind,
                             dispatch_share_solar,  
                             dispatch_share_storage,
                             dispatch_share_nuclear])

# set up figure layout and size
fig, ax = plt.subplots(1,4, figsize=(7.2,1.5), sharex=True, sharey=True)

for i in range(len(ax)):
    
    # x-axis = varying nuclear cost scalings
    nuclear_cost_multiples = fixed_cost_nuclear[np.array(range(cols)) + i*cols]/fixed_cost_nuclear[0]
    
    # fill in subplots    
    ax[i].stackplot(nuclear_cost_multiples, dispatch_shares[0:,np.array(range(cols)) + i*cols], colors=colors)
                     
    # subplot title = selected renewable cost scalings
    renewables_cost_multiples = fixed_cost_solar[i*cols]/fixed_cost_solar[0]
    title = '%.2g' % renewables_cost_multiples + u'\xd7' + '\n renewable costs'
    ax[i].set_title(title, fontsize=10)
    
    # axis ticks and limits
    ax[i].set_xticks([0,0.2,0.4,0.6,0.8,1])
    ax[i].set_yticks([0,0.2,0.4,0.6,0.8,1])
    ax[i].xaxis.set_major_formatter(FormatStrFormatter('%.1g'))
    ax[i].yaxis.set_major_formatter(FormatStrFormatter('%.1g'))
    plt.ylim(0,1)

# title, axis labels, legend
xlabel = 'Nuclear costs (1 = EIA 2018 cost estimates)'
ylabel = 'Dispatch\n(1 = average demand)'
legend = ['Wind', 'Solar', 'Storage', 'Nuclear']
fig.text(0.51, -0.12, xlabel, horizontalalignment='center', fontsize=10)
ax[0].set_ylabel(ylabel,fontsize=10)
ax[0].legend(labels=legend, fancybox=False, frameon=False, 
             loc='lower left', bbox_to_anchor=(0.56,-0.75), ncol=4, fontsize=10)        

# adjust spacing within and around subplots
plt.autoscale(enable=True, axis='x', tight=True)

## save plot
#fig.savefig(file_path + 'figures/' + '2.dispatch mix' + '.png', 
#            dpi=300, bbox_inches='tight', pad_inches=0.2)


plt.show()
