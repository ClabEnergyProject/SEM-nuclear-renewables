"""
file name: plot_value_of_flexibility.py
    plot differences in system cost between constant and flexible nuclear cases
    as functions of nuclear and renewable costs (supplementary figures)
"""

#%% import modules

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.ticker import FormatStrFormatter

#%% global plot settings

# set rcParams back to default values
#     reference: https://stackoverflow.com/questions/26413185/how-to-recover-matplotlib-defaults-after-setting-stylesheet
mpl.rcParams.update(mpl.rcParamsDefault)

# tick directions and font
mpl.rcParams['xtick.direction'] = 'in'
mpl.rcParams['ytick.direction'] = 'in'

# font and fontsize
    # reference: https://ask.sagemath.org/question/8882/change-legend-font-when-plotting/
    # reference on font family: https://matplotlib.org/examples/api/font_family_rc.html
plt.rc('font',**{'family':'sans-serif','sans-serif':['Arial'],'size':8})

#%% specify file path and file name

## Case #1 and Case #2
#file_path_c = '../ngccs_const_nuc/'
#file_name_c = 'ngccs_const_nuc_20181028_225617'
#file_path_f = '../ngccs_flex_nuc/'
#file_name_f = 'ngccs_flex_nuc_20181029_143001'
#
## Case #3 and Case #4
#file_path_c = '../ng_const_nuc/'
#file_name_c = 'ng_const_nuc_20181029_115143'
#file_path_f = '../ng_flex_nuc/'
#file_name_f = 'ng_flex_nuc_20181029_154218'

# Case #5 and Case #6
file_path_c = '../no_ng_const_nuc/'
file_name_c = 'no_ng_const_nuc_20181029_193527'
file_path_f = '../no_ng_flex_nuc/'
file_name_f = 'no_ng_flex_nuc_20181029_163432'

#%% read results from summary .csv files

# read data from .csv files as dataframes
    # reference: https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.html
df_c = pd.read_csv(file_path_c + file_name_c + '.csv')
df_f = pd.read_csv(file_path_f + file_name_f + '.csv')

# assign data to variable names
fixed_cost_solar_c = df_c['fixed cost solar ($/kW/h)'].values
fixed_cost_wind_c = df_c['fixed cost wind ($/kW/h)'].values
fixed_cost_nuclear_c = df_c['fixed cost nuclear ($/kW/h)'].values
fixed_cost_solar_f = df_f['fixed cost solar ($/kW/h)'].values
fixed_cost_wind_f = df_f['fixed cost wind ($/kW/h)'].values
fixed_cost_nuclear_f = df_f['fixed cost nuclear ($/kW/h)'].values
system_cost_c = df_c['system cost ($/kW/h)'].values
system_cost_f = df_f['system cost ($/kW/h)'].values

#%% calculations

# number of columns arrays are reshaped into
cols = np.unique(fixed_cost_nuclear_c).shape[0]

# cost scalings for contour plots
nuclear_cost_multiples = fixed_cost_nuclear_c/fixed_cost_nuclear_c[0]     # nuclear fixed cost
renewables_cost_multiples = fixed_cost_solar_c/fixed_cost_solar_c[0]      # renewables fixed cost

# difference in system cost
delta_system_cost = system_cost_c - system_cost_f
rel_delta_system_cost = delta_system_cost / system_cost_c

#%% contour plot: relative difference in system cost

# set up figure layout and size
fig, ax = plt.subplots(1,1, figsize=(2.5,2.5), sharex=True, sharey=True)

# plot contour and with chosen colorbar limits
    # reference on colorbar limits: 
        # https://stackoverflow.com/questions/5826592/python-matplotlib-colorbar-range-and-display-values
    # references on colorbar formatting:
        # https://matplotlib.org/gallery/subplots_axes_and_figures/subplots_adjust.html#sphx-glr-gallery-subplots-axes-and-figures-subplots-adjust-py
        # https://matplotlib.org/examples/pylab_examples/contourf_demo.html
        # https://jakevdp.github.io/PythonDataScienceHandbook/04.07-customizing-colorbars.html
cmap = plt.get_cmap('viridis')
v_cf = np.linspace(-1E-6,20,501)  # filled contour color levels
v_c = np.linspace(-1E-6,20,11)    # contour line heights

# relative difference in system cost
cf = ax.contourf(nuclear_cost_multiples.reshape(-1,cols), 
                     renewables_cost_multiples.reshape(-1,cols),
                     100*rel_delta_system_cost.reshape(-1,cols), v_cf, cmap=cmap)     

# axis ticks
ax.set_xticks([0, 0.2, 0.4, 0.6, 0.8, 1])
ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1])
ax.xaxis.set_major_formatter(FormatStrFormatter('%.1g'))
ax.yaxis.set_major_formatter(FormatStrFormatter('%.1g'))

# color bar
cb = plt.colorbar(cf, ticks=np.linspace(0,20,11), format='%.0f%%', 
                    cax=plt.axes([1, 0.11, 0.05, 0.77]))
cb.set_label(label='% Difference in system cost', fontsize=10,
               rotation=270, verticalalignment='bottom')

# title and axis labels
xlabel = 'Nuclear costs\n(1 = EIA 2018 cost estimates)'
ylabel = 'Wind and solar costs\n(1 = EIA 2018 cost estimates)'
ax.set_xlabel(xlabel, fontsize=10)                  # x-axis label
ax.set_ylabel(ylabel, fontsize=10)                  # y-axis label

## save plot
#fig.savefig(file_path_c + 'figures/' + '5a.rel delta system cost' + '.png', 
#            dpi=300, bbox_inches='tight', pad_inches=0.2)
## save plot
#fig.savefig(file_path_f + 'figures/' + '5a.rel delta system cost' + '.png', 
#            dpi=300, bbox_inches='tight', pad_inches=0.2)


plt.show()
