"""
file name: figs_contour_system_cost.py
    plot system costs as functions of nuclear and renewable costs 
    (supplementary figures)
"""

#%% import modules

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.ticker import FormatStrFormatter

#%% global plot settings

# set rcParams back to default values
    # reference: https://stackoverflow.com/questions/26413185/how-to-recover-matplotlib-defaults-after-setting-stylesheet
mpl.rcParams.update(mpl.rcParamsDefault)

# ticks
mpl.rcParams['xtick.direction'] = 'in'
mpl.rcParams['ytick.direction'] = 'in'

# font and fontsize
    # reference: https://ask.sagemath.org/question/8882/change-legend-font-when-plotting/
    # reference on font family: https://matplotlib.org/examples/api/font_family_rc.html
plt.rc('font',**{'family':'sans-serif','sans-serif':['Arial'],'size':8})

#%% specify file path and file name

# Case #1: NGCC + CCS, constant nuclear
file_path = '../ngccs_const_nuc-41by41/'
file_name = 'ngccs_const_nuc-41by41_20181106_210545'

## Case #2: NGCC + CCS, flexible nuclear
#file_path = '../ngccs_flex_nuc/'
#file_name = 'ngccs_flex_nuc_20181029_143001'

## Case #3: NGCC, constant nuclear
#file_path = '../ng_const_nuc/'
#file_name = 'ng_const_nuc_20181029_115143'

## Case #4: NGCC, flexible nuclear
#file_path = '../ng_flex_nuc/'
#file_name = 'ng_flex_nuc_20181029_154218'

## Case #5: No NG, constant nuclear
#file_path = '../no_ng_const_nuc/'
#file_name = 'no_ng_const_nuc_20181029_193527'

## Case #5: No NG, flexible nuclear
#file_path = '../no_ng_flex_nuc/'
#file_name = 'no_ng_flex_nuc_20181029_163432'

directory = file_path + 'figures'
if not os.path.exists(directory):
    os.mkdir(directory)

#%% read results from summary .csv files

# read data from .csv files as dataframes
    # reference: https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.html
df = pd.read_csv(file_path + file_name + '.csv')

# assign data to variable names
fixed_cost_natgas = df['fixed cost natgas ($/kW/h)'].values
fixed_cost_solar = df['fixed cost solar ($/kW/h)'].values
fixed_cost_wind = df['fixed cost wind ($/kW/h)'].values
fixed_cost_nuclear = df['fixed cost nuclear ($/kW/h)'].values
system_cost = df['system cost ($/kW/h)'].values

#%% calculations

# number of columns arrays are reshaped into
cols = np.unique(fixed_cost_nuclear).shape[0]
rows = np.unique(fixed_cost_solar).shape[0]

# cost scalings for contour plots
cost_multiples_nuclear = fixed_cost_nuclear/fixed_cost_nuclear[0]
cost_multiples_renewables = fixed_cost_solar/fixed_cost_solar[0]

#%% contour plot: system cost vs. nuclear and renewables costs

# set up figure layout and size
fig, ax = plt.subplots(1,1, figsize=(2.5,2.5), sharex=True, sharey=True)

# contour heights and colormap
cmap_cf = plt.get_cmap('magma_r')
# contour levels, NGCC + CCS
v_cf = np.linspace(0,0.08,501)  # filled contour color levels
v_c = np.linspace(0,0.08,9)     # contour line heights
## contour levels, NGCC
#v_cf = np.linspace(0,0.05,501)  # filled contour color levels
#v_c = np.linspace(0,0.05,6)     # contour line heights
## contour levels, no NGCC
#v_cf = np.linspace(0,0.15,501)  # filled contour color levels
#v_c = np.linspace(0,0.15,6)     # contour line heights
# contour line colors, number of colors = number of colorbar ticks - 2
colors_clines = ['k','k','k','lightsalmon','lemonchiffon','lemonchiffon','lemonchiffon']    # NGCC + CCS
#colors_clines = ['k','k','lemonchiffon','lemonchiffon']     # NGCC / no NG

# system cost
cf = ax.contourf(cost_multiples_nuclear.reshape(-1,cols), 
                     cost_multiples_renewables.reshape(-1,cols),
                     system_cost.reshape(-1,cols), 
                     v_cf, cmap=cmap_cf)     
c = ax.contour(cost_multiples_nuclear.reshape(-1,cols), 
                   cost_multiples_renewables.reshape(-1,cols),
                   system_cost.reshape(-1,cols), 
                   v_c, colors=colors_clines, linewidths=0.5, linestyles='--')

# axis ticks
ax.set_xticks([0, 0.2, 0.4, 0.6, 0.8, 1])
ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1])
ax.xaxis.set_major_formatter(FormatStrFormatter('%.1g'))
ax.yaxis.set_major_formatter(FormatStrFormatter('%.1g'))

# color bar
cb = plt.colorbar(cf, ticks=v_c, cax=plt.axes([1, 0.11, 0.05, 0.77]))
cb.set_label(label='Total system cost [$/kWh]', fontsize=10,
               rotation=270, verticalalignment='bottom')
# horizontal lines on color bar
    # line positions = 1/(# colorbar ticks - 1)*[1 up to (# colorbar ticks - 2)]
# NGCC + CCS
cb.ax.hlines(1/8*np.array([1,2,3,4,5,6,7]), 0, 1, 
               colors=colors_clines,
               linewidth=0.5, linestyles='--')
## NGCC / no NGCC
#cb.ax.hlines(1/5*np.array([1,2,3,4]), 0, 1, 
#               colors=colors_clines,
#               linewidth=0.5, linestyles='--')

# title and axis labels
xlabel = 'Nuclear costs\n(1 = EIA 2018 cost estimates)'
ylabel = 'Wind and solar costs\n(1 = EIA 2018 cost estimates)'
ax.set_xlabel(xlabel, fontsize=10)
ax.set_ylabel(ylabel, fontsize=10)

## save plot
#fig.savefig(file_path + 'figures/' + '.system cost contour' + '.png', 
#              dpi=300, bbox_inches='tight', pad_inches=0.2)
#


plt.show()
