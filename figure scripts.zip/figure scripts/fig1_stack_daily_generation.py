"""
file name: fig1_stack_daily_generation.py
    plot daily-averaged demand and generation for each technology for selected
    renewable and nuclear costs (Figure 1)
"""

#%% import modules

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.legend import Legend

#%% global plot settings

# set rcParams back to default values
    # reference: https://stackoverflow.com/questions/26413185/how-to-recover-matplotlib-defaults-after-setting-stylesheet
mpl.rcParams.update(mpl.rcParamsDefault)

# ticks
mpl.rcParams['xtick.direction'] = 'in'
mpl.rcParams['ytick.direction'] = 'in'

# font and fontsize
    # reference: https://ask.sagemath.org/question/8882/change-legend-font-when-plotting/
    # reference on font family: https://matplotlib.org/examples/api/font_family_rc.html
plt.rc('font',**{'family':'sans-serif','sans-serif':['Arial'],'size':10})

#%% color palette
# colors from: http://colorbrewer2.org/#type=diverging&scheme=BrBG&n=4

# colorblind-friendly
color_wind    = '#006d2c'   # green, dark
color_solar   = '#c7e9c0'   # green, light
color_nuclear = '#de2d26'   # red, dark
color_natgas  = '#6baed6'   # blue, medium

# generation (dispatch + curtailment) time series
colors = [color_wind, color_solar, color_nuclear, color_natgas, 
           color_wind, color_solar, color_nuclear]        

#%% specify file path and file name

# select cost scalings for plot, minimum increment = 0.025
# at given costs of renewables, plot dispatch for varying costs of nuclear
renewable_costs = 0.5
nuclear_costs = [1,0.5,0.25]

file_path = '../ngccs_const_nuc-41by41/'
file_name1 = 'ngccs_const_nuc-41by41_'     

directory = file_path + 'figures'
if not os.path.exists(directory):
    os.mkdir(directory)

#%% read in hourly results, calculate daily averages, and plot results

for nc in range(len(nuclear_costs)):
    
    # file to read in (varies with nuclear costs)    
    file_name2 = 'renew' + str(int(renewable_costs*1000)).zfill(4) + \
                 'nuc' + str(int(nuclear_costs[nc]*1000)).zfill(4)

    # read data from .csv files as dataframes
        # reference: https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.html
    df = pd.read_csv(file_path + file_name1 + file_name2 + '.csv')
    
    # assign data to variable names
    demand = df['demand (kW)'].values
    dispatch_solar = df['dispatch solar (kW per unit deployed)'].values
    dispatch_wind = df['dispatch wind (kW per unit deployed)'].values
    dispatch_natgas = df['dispatch natgas (kW)'].values
    dispatch_nuclear = df['dispatch nuclear (kW)'].values
    curtailment_solar = df['curtailment solar (kW)'].values
    curtailment_wind = df['curtailment wind (kW)'].values
    curtailment_nuclear = df['curtailment nuclear (kW)'].values

    # daily averages of demand, dispatch, curtailment
    demand_daily = np.mean(demand.reshape(-1,24), axis=1)
    dispatch_natgas_daily = np.mean(dispatch_natgas.reshape(-1,24), axis=1)
    dispatch_solar_daily = np.mean(dispatch_solar.reshape(-1,24), axis=1)
    dispatch_wind_daily = np.mean(dispatch_wind.reshape(-1,24), axis=1)
    dispatch_nuclear_daily = np.mean(dispatch_nuclear.reshape(-1,24), axis=1)
    curtailment_solar_daily = np.mean(curtailment_solar.reshape(-1,24), axis=1)
    curtailment_wind_daily = np.mean(curtailment_wind.reshape(-1,24), axis=1)
    curtailment_nuclear_daily = np.mean(curtailment_nuclear.reshape(-1,24), axis=1)
    
    # stack up dispatch and curtailment                                    
    dispatch_daily = np.vstack([dispatch_wind_daily,
                                dispatch_solar_daily,
                                dispatch_nuclear_daily,
                                dispatch_natgas_daily])
    
    curtailment_daily = np.vstack([curtailment_wind_daily,
                                   curtailment_solar_daily,
                                   curtailment_nuclear_daily])
    
    # hours in year, days in year
    hours = len(dispatch_natgas)
    days = int(hours/24)
    
    # set up figure layout and size
    fig, ax = plt.subplots(1,1, figsize=(6,1.5), sharex=True, sharey=True)
    
    # plot daily averages of demand, dispatch, and curtailment
    ax.plot(range(days), demand_daily, 'k', linewidth=1)
    p = ax.stackplot(range(days), np.vstack([dispatch_daily, curtailment_daily]), 
                      colors=colors)
        
    # title, axis labels, legend
        # reference on multiple legends: https://jakevdp.github.io/PythonDataScienceHandbook/04.06-customizing-legends.html
    title = str(renewable_costs) + u'\xd7' + ' renewable costs, ' + \
            str(nuclear_costs[nc]) + u'\xd7' + ' nuclear costs'
    xlabel = 'Day of year'
    ylabel = 'Demand or generation\n(1 = average demand)'
    legend_a = ['Demand']
    legend_b = ['Wind', 'Solar', 'Nuclear', 'Natural gas']
    ax.set_title(title, fontsize=12)
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    plt.ylim([0,2.5])
    ax.set_yticks([0,1,2])
    ax.legend(labels=legend_a, fancybox=False, frameon=False, 
              loc='upper center', bbox_to_anchor=(0.5,-0.75), fontsize=10)
    leg = Legend(ax, p, labels=legend_b, fancybox=False, frameon=False, 
                 loc='upper center', bbox_to_anchor=(0.5,-0.46), ncol=4, fontsize=10)
    ax.add_artist(leg)
    # adjust spacing within and around subplots
        # references: 
            # https://stackoverflow.com/questions/37558329/matplotlib-set-axis-tight-only-to-x-or-y-axis
            # https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplots_adjust.html
    plt.autoscale(enable=True, axis='x', tight=True)
    
#    # save plot
#    fig.savefig(file_path + 'figures/' + '1.dispatch_' + file_name2 + '.png', 
#                 dpi=300, bbox_inches='tight', pad_inches=0.2)
    
    
    plt.show()
