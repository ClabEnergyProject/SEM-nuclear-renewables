"""
file name: fig3_contour_dispatch.py
    plot dispatch shares of (a) wind and solar, (b) nuclear, and (c) natural gas
    as functions of nuclear and renewable costs (Figure 3 and supplementary figures)
"""

#%% import modules

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.ticker import FormatStrFormatter

#%% global plot settings

# set rcParams back to default values
    # reference: https://stackoverflow.com/questions/26413185/how-to-recover-matplotlib-defaults-after-setting-stylesheet
mpl.rcParams.update(mpl.rcParamsDefault)

# ticks
mpl.rcParams['xtick.direction'] = 'in'
mpl.rcParams['ytick.direction'] = 'in'

# font and fontsize
    # reference: https://ask.sagemath.org/question/8882/change-legend-font-when-plotting/
    # reference on font family: https://matplotlib.org/examples/api/font_family_rc.html
plt.rc('font',**{'family':'sans-serif','sans-serif':['Arial'],'size':8})

#%% specify file path and file name

# Case #1: NGCC + CCS, constant nuclear
file_path = '../ngccs_const_nuc-41by41/'
file_name = 'ngccs_const_nuc-41by41_20181106_210545'

## Case #2: NGCC + CCS, flexible nuclear
#file_path = '../ngccs_flex_nuc/'
#file_name = 'ngccs_flex_nuc_20181029_143001'

## Case #3: NGCC, constant nuclear
#file_path = '../ng_const_nuc/'
#file_name = 'ng_const_nuc_20181029_115143'

## Case #4: NGCC, flexible nuclear
#file_path = '../ng_flex_nuc/'
#file_name = 'ng_flex_nuc_20181029_154218'

## Case #5: No NG, constant nuclear
#file_path = '../no_ng_const_nuc/'
#file_name = 'no_ng_const_nuc_20181029_193527'

## Case #5: No NG, flexible nuclear
#file_path = '../no_ng_flex_nuc/'
#file_name = 'no_ng_flex_nuc_20181029_163432'

directory = file_path + 'figures'
if not os.path.exists(directory):
    os.mkdir(directory)

#%% read results from summary .csv files

# read data from .csv files as dataframes
    # reference: https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.html
df = pd.read_csv(file_path + file_name + '.csv')

# assign data to variable names
fixed_cost_solar = df['fixed cost solar ($/kW/h)'].values
fixed_cost_wind = df['fixed cost wind ($/kW/h)'].values
fixed_cost_nuclear = df['fixed cost nuclear ($/kW/h)'].values
dispatch_natgas = df['dispatch natgas (kW)'].values
dispatch_solar = df['dispatch solar (kW)'].values
dispatch_wind = df['dispatch wind (kW)'].values
dispatch_nuclear = df['dispatch nuclear (kW)'].values

#%% calculations

# number of columns arrays are reshaped into
cols = np.unique(fixed_cost_nuclear).shape[0]
rows = np.unique(fixed_cost_solar).shape[0]

# calculate dispatch shares
tot_dispatch = dispatch_natgas + dispatch_solar + dispatch_wind + dispatch_nuclear  # = demand
dispatch_share_nuclear = dispatch_nuclear / tot_dispatch
dispatch_share_solar = dispatch_solar / tot_dispatch
dispatch_share_wind = dispatch_wind / tot_dispatch
dispatch_share_renewables = (dispatch_solar + dispatch_wind) / tot_dispatch
dispatch_share_natgas = dispatch_natgas / tot_dispatch

# cost scalings for contour plots
cost_multiples_nuclear = fixed_cost_nuclear/fixed_cost_nuclear[0]
cost_multiples_renewables = fixed_cost_solar/fixed_cost_solar[0]

#%% contour plot: dispatch shares vs. nuclear and renewable costs

# set up figure layout and size
fig, ax = plt.subplots(1,3, figsize=(7,2), sharex=True, sharey=True)

# contour heights and colormap
cmap_cf = plt.get_cmap('magma_r')
v_cf = np.linspace(0,100,501)   # filled contour heights
v_c = np.linspace(0,100,6)      # contour line heights

# share of dispatch: solar + wind
ax[0].contourf(cost_multiples_nuclear.reshape(-1,cols), 
               cost_multiples_renewables.reshape(-1,cols), 
               100*dispatch_share_renewables.reshape(-1,cols), 
               v_cf, cmap=cmap_cf)
ax[0].contour(cost_multiples_nuclear.reshape(-1,cols), 
              cost_multiples_renewables.reshape(-1,cols), 
              100*dispatch_share_renewables.reshape(-1,cols),
              v_c, colors=['k','k','lemonchiffon','lemonchiffon'],
              linewidths=0.5, linestyles='--')
                                
# share of dispatch: nuclear
ax[1].contourf(cost_multiples_nuclear.reshape(-1,cols), 
               cost_multiples_renewables.reshape(-1,cols), 
               100*dispatch_share_nuclear.reshape(-1,cols), 
               v_cf, cmap=cmap_cf)     
ax[1].contour(cost_multiples_nuclear.reshape(-1,cols), 
              cost_multiples_renewables.reshape(-1,cols), 
              100*dispatch_share_nuclear.reshape(-1,cols), 
              v_c, colors=['k','k','lemonchiffon','lemonchiffon'],
              linewidths=0.5, linestyles='--')

# share of dispatch: natural gas
cf = ax[2].contourf(cost_multiples_nuclear.reshape(-1,cols), 
                    cost_multiples_renewables.reshape(-1,cols), 
                    100*dispatch_share_natgas.reshape(-1,cols), 
                    v_cf, cmap=cmap_cf)
ax[2].contour(cost_multiples_nuclear.reshape(-1,cols), 
              cost_multiples_renewables.reshape(-1,cols), 
              100*dispatch_share_natgas.reshape(-1,cols), 
              v_c, colors=['k','k','lemonchiffon','lemonchiffon'],
              linewidths=0.5, linestyles='--')

# axis ticks
ax[0].set_xticks([0, 0.2, 0.4, 0.6, 0.8, 1])
ax[0].set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1])
ax[0].xaxis.set_major_formatter(FormatStrFormatter('%.1g'))
ax[0].yaxis.set_major_formatter(FormatStrFormatter('%.1g'))

# color bar
cb = plt.colorbar(cf, ticks=v_c, format='%.0f%%', 
                  cax=plt.axes([0.93, 0.105, 0.02, 0.78]))
cb.set_label(label='Share of dispatch', fontsize=10,
             rotation=270, verticalalignment='bottom')
cb.ax.hlines([0.2, 0.4, 0.6, 0.8], 0, 1, 
             colors=['k','k','lemonchiffon','lemonchiffon'],
             linewidth=0.5, linestyles='--')

# title and axis labels
xlabel = 'Nuclear costs (1 = EIA 2018 cost estimates)'
ylabel = 'Wind and solar costs\n(1 = EIA 2018 cost estimates)'
ax[1].set_xlabel(xlabel, fontsize=10)
ax[0].set_ylabel(ylabel, fontsize=10)
ax[0].set_title('Wind + Solar', fontsize=10)
ax[1].set_title('Nuclear', fontsize=10)
ax[2].set_title('Natural gas', fontsize=10)

## save plot
#fig.savefig(file_path + 'figures/' + '4.dispatch shares contour' + '.png', 
#              dpi=300, bbox_inches='tight', pad_inches=0.2)
       
#%% contour plot: dispatch shares vs. nuclear and renewable costs, vertical orientation

# set up figure layout and size
fig, ax = plt.subplots(3,1, figsize=(2.5,8), sharex=True, sharey=True)

# contour heights and colormap
cmap_cf = plt.get_cmap('magma_r')
v_cf = np.linspace(0,100,501)   # filled contour heights
v_c = np.linspace(0,100,6)      # contour line heights

# share of dispatch: solar + wind
ax[0].contourf(cost_multiples_nuclear.reshape(-1,cols), 
               cost_multiples_renewables.reshape(-1,cols), 
               100*dispatch_share_renewables.reshape(-1,cols), 
               v_cf, cmap=cmap_cf)
ax[0].contour(cost_multiples_nuclear.reshape(-1,cols), 
              cost_multiples_renewables.reshape(-1,cols), 
              100*dispatch_share_renewables.reshape(-1,cols),
              v_c, colors=['k','k','lemonchiffon','lemonchiffon'],
              linewidths=0.5, linestyles='--')
                                
# share of dispatch: nuclear
ax[1].contourf(cost_multiples_nuclear.reshape(-1,cols), 
               cost_multiples_renewables.reshape(-1,cols), 
               100*dispatch_share_nuclear.reshape(-1,cols), 
               v_cf, cmap=cmap_cf)     
ax[1].contour(cost_multiples_nuclear.reshape(-1,cols), 
              cost_multiples_renewables.reshape(-1,cols), 
              100*dispatch_share_nuclear.reshape(-1,cols), 
              v_c, colors=['k','k','lemonchiffon','lemonchiffon'],
              linewidths=0.5, linestyles='--')

# share of dispatch: natural gas
cf = ax[2].contourf(cost_multiples_nuclear.reshape(-1,cols), 
                    cost_multiples_renewables.reshape(-1,cols), 
                    100*dispatch_share_natgas.reshape(-1,cols), 
                    v_cf, cmap=cmap_cf)
ax[2].contour(cost_multiples_nuclear.reshape(-1,cols), 
              cost_multiples_renewables.reshape(-1,cols), 
              100*dispatch_share_natgas.reshape(-1,cols), 
              v_c, colors=['k','k','lemonchiffon','lemonchiffon'],
              linewidths=0.5, linestyles='--')

# axis ticks
ax[0].set_xticks([0, 0.2, 0.4, 0.6, 0.8, 1])
ax[0].set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1])
ax[0].xaxis.set_major_formatter(FormatStrFormatter('%.1g'))
ax[0].yaxis.set_major_formatter(FormatStrFormatter('%.1g'))

# color bar
cb = plt.colorbar(cf, ticks=v_c, format='%.0f%%', orientation='horizontal',
                  cax=plt.axes([0.122, -0.01, 0.78, 0.02]))
cb.set_label(label='Share of dispatch', fontsize=10)
cb.ax.vlines([0.2, 0.4, 0.6, 0.8], 0, 1, 
             colors=['k','k','lemonchiffon','lemonchiffon'],
             linewidth=0.5, linestyles='--')

# title and axis labels
xlabel = 'Nuclear costs\n(1 = EIA 2018 cost estimates)'
ylabel = 'Wind and solar costs (1 = EIA 2018 cost estimates)'
ax[2].set_xlabel(xlabel, fontsize=10)
fig.text(-0.06, 0.3, ylabel, rotation=90, verticalalignment='bottom', fontsize=10)
ax[0].set_title('Wind + Solar', fontsize=10)
ax[1].set_title('Nuclear', fontsize=10)
ax[2].set_title('Natural gas', fontsize=10)

## save plot
#fig.savefig(file_path + 'figures/' + '4.dispatch shares contour_vertical' + '.png', 
#              dpi=300, bbox_inches='tight', pad_inches=0.2)


plt.show()
